// ===== E-Waste Smart Collection & Reuse Portal =====
const STORAGE_KEY = "ewasteRecords";

// ---- Helpers to read/write records in the browser's localStorage ----
function loadRecords() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
  catch (e) { return []; }
}
function saveRecords(records) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

// ---- Rule-based recommendation ----
// Returns { type, title, text, warnings[] }
function getRecommendation(category, condition) {
  const warnings = [];
  if (category === "Battery") {
    warnings.push("Battery safety: do not puncture, heat or throw it in ordinary waste. Store it in a cool, dry place and give it to an authorised battery collection or recycling point.");
    return { type: "Recycle", title: "Appropriate battery collection and recycling",
      text: "Batteries can leak or catch fire. They must go to an authorised collection point.", warnings };
  }
  if (category === "Mobile Phone" || category === "Laptop / Computer") {
    warnings.push("Data privacy: back up your files, log out of all accounts and factory-reset the device before handing it over.");
  }
  if (condition === "Working") {
    return { type: "Reuse", title: "Assess for safe reuse",
      text: "This item still works. Check it is safe, then donate, sell or pass it on to extend its life.", warnings };
  }
  if (condition === "Minor Issue") {
    return { type: "Repair", title: "Professional repair assessment",
      text: "Ask a qualified technician whether it can be repaired. Repairing is usually better than replacing.", warnings };
  }
  return { type: "Recycle", title: "Authorised e-waste recycling",
    text: "This item is unusable. Give it to an authorised e-waste recycler. Do not put it in ordinary dustbins.", warnings };
}

// ---- Escape text so user input can't inject HTML ----
function esc(s) {
  const d = document.createElement("div");
  d.textContent = s;
  return d.innerHTML;
}

// ---- Show the recommendation card ----
function showResult(rec, name) {
  const box = document.getElementById("result");
  const cls = "rec-" + rec.type.toLowerCase();
  box.className = "card " + cls;
  box.innerHTML = `<h3>${esc(rec.title)}</h3>
    <p><b>${esc(name)}</b> registered successfully.</p>
    <p>${esc(rec.text)}</p>` +
    rec.warnings.map(w => `<div class="warn">⚠ ${esc(w)}</div>`).join("");
}

// ---- Form handling and validation ----
document.getElementById("wasteForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const name = document.getElementById("itemName").value.trim();
  const category = document.getElementById("category").value;
  const quantity = Number(document.getElementById("quantity").value);
  const condition = document.getElementById("condition").value;
  const notes = document.getElementById("notes").value.trim();
  const err = document.getElementById("error");

  if (name.length < 2) { err.textContent = "Please enter an item name (at least 2 characters)."; return; }
  if (!category) { err.textContent = "Please select a category."; return; }
  if (!Number.isInteger(quantity) || quantity < 1) { err.textContent = "Quantity must be a whole number of 1 or more."; return; }
  if (!condition) { err.textContent = "Please select the item's condition."; return; }
  err.textContent = "";

  const rec = getRecommendation(category, condition);
  const records = loadRecords();
  records.push({ name, category, quantity, condition, notes, recommendation: rec.type, demo: false });
  saveRecords(records);

  showResult(rec, name);
  this.reset();
  document.getElementById("quantity").value = 1;
  renderDashboard();
});

// ---- Dashboard ----
function renderDashboard() {
  const records = loadRecords();
  const count = t => records.filter(r => r.recommendation === t).reduce((s, r) => s + r.quantity, 0);

  document.getElementById("statRecords").textContent = records.length;
  document.getElementById("statQty").textContent = records.reduce((s, r) => s + r.quantity, 0);
  document.getElementById("statReuse").textContent = count("Reuse");
  document.getElementById("statRepair").textContent = count("Repair");
  document.getElementById("statRecycle").textContent = count("Recycle");

  // Category bar chart (made with plain HTML/CSS, no library needed)
  const byCat = {};
  records.forEach(r => byCat[r.category] = (byCat[r.category] || 0) + r.quantity);
  const max = Math.max(1, ...Object.values(byCat));
  const chart = document.getElementById("chart");
  chart.innerHTML = Object.keys(byCat).length
    ? Object.entries(byCat).map(([c, n]) =>
        `<div class="bar-row"><span class="bar-label">${esc(c)}</span><div class="bar" style="width:${(n / max) * 70 + 5}%">${n}</div></div>`).join("")
    : '<p class="muted">No data to chart yet.</p>';

  // Table
  document.getElementById("tableBody").innerHTML = records.map(r =>
    `<tr><td>${esc(r.name)}</td><td>${esc(r.category)}</td><td>${r.quantity}</td><td>${esc(r.condition)}</td>
     <td>${esc(r.recommendation)}</td><td><span class="tag ${r.demo ? "" : "real"}">${r.demo ? "Demo" : "Entered by you"}</span></td></tr>`).join("");
  document.getElementById("empty").hidden = records.length > 0;
}

// ---- Demo data ----
document.getElementById("demoBtn").addEventListener("click", function () {
  const samples = [
    ["Old laptop", "Laptop / Computer", 2, "Working"],
    ["Cracked phone", "Mobile Phone", 3, "Minor Issue"],
    ["Dead power bank battery", "Battery", 4, "Unusable"],
    ["Tangled chargers", "Charger / Cable", 6, "Unusable"],
    ["Mixer grinder", "Home Appliance", 1, "Minor Issue"]
  ];
  const records = loadRecords();
  samples.forEach(([name, category, quantity, condition]) =>
    records.push({ name, category, quantity, condition, notes: "", recommendation: getRecommendation(category, condition).type, demo: true }));
  saveRecords(records);
  renderDashboard();
});

// ---- Confirmation dialog before clearing ----
const dialog = document.getElementById("confirmDialog");
document.getElementById("clearBtn").addEventListener("click", () => {
  document.getElementById("dialogText").textContent = "This will delete all saved records. This cannot be undone.";
  dialog.showModal();
});
document.getElementById("cancelBtn").addEventListener("click", () => dialog.close());
document.getElementById("confirmBtn").addEventListener("click", () => {
  localStorage.removeItem(STORAGE_KEY);
  dialog.close();
  renderDashboard();
});

// Show saved data when the page loads
renderDashboard();
